# Copyright 2023 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Classes for working with the Gemini models."""
# pylint: disable=bad-continuation, line-too-long

import io
import pathlib
from typing import Any, AsyncIterable, Dict, Iterable, List, Optional, Sequence, Union

try:
    from PIL import Image as PIL_Image
except ImportError:
    PIL_Image = None

_USE_LABS = False

try:
    from google.cloud.aiplatform import initializer as aiplatform_initializer
    from google.cloud.aiplatform_v1beta1.services import prediction_service
    from google.cloud.aiplatform_v1beta1.types import content as content_types
    from google.cloud.aiplatform_v1beta1.types import prediction_service as prediction_service_types
except:
    from google.cloud.aiplatform import initializer as aiplatform_initializer
    from google.cloud.aiplatform_v1beta1.services import prediction_service
    from google.cloud.aiplatform_v1beta1.types import content as content_types
    from google.cloud.aiplatform_v1beta1.types import prediction_service as prediction_service_types


_PREDICTION_API_BASE_PATH = "autopush-aiplatform.sandbox.googleapis.com"

# These type defnitions are expanded to help the user see all the types
PartsType = Union[
    content_types.Part,
    str,
    "Image",
    List[Union[content_types.Part, str, "Image"]],
]

ContentsType = Union[
    List[content_types.Content],
    content_types.Content,
    content_types.Part,
    str,
    "Image",
    List[Union[content_types.Part, str, "Image"]],
]


GenerationConfigType = Union[
    content_types.GenerationConfig,
    Dict[str, Any],
]

SafetySettingsType = Union[
    content_types.SafetySetting,
    Dict[content_types.HarmCategory, content_types.SafetySetting.HarmBlockThreshold],
]


class GenerativeModel:

    _USER_ROLE = "user"
    _MODEL_ROLE = "assistant"

    def __init__(
        self,
        model_name: str = "gemini-pro",
    ):
        if "/" not in model_name:
            model_name = "publishers/google/models/" + model_name

        project = aiplatform_initializer.global_config.project
        location = aiplatform_initializer.global_config.location

        self._model_name = model_name
        self._prediction_model_name = f"projects/{project}/locations/{location}/{model_name}"

    @property
    def _prediction_client(self) -> prediction_service.PredictionServiceClient:
        # Switch to @functools.cached_property once its available.
        if not getattr(self, "_prediction_client_value", None):
            self._prediction_client_value = aiplatform_initializer.global_config.create_client(
                client_class=prediction_service.PredictionServiceClient,
                api_base_path_override=_PREDICTION_API_BASE_PATH,
                prediction_client=True,
            )
        return self._prediction_client_value

    @property
    def _prediction_async_client(self) -> prediction_service.PredictionServiceAsyncClient:
        # Switch to @functools.cached_property once its available.
        if not getattr(self, "_prediction_async_client_value", None):
            self._prediction_async_client_value = (
                aiplatform_initializer.global_config.create_client(
                    client_class=prediction_service.PredictionServiceAsyncClient,
                    api_base_path_override=_PREDICTION_API_BASE_PATH,
                    prediction_client=True,
                )
            )
        return self._prediction_async_client_value

    def _prepare_request(
        self,
        contents: ContentsType,
        *,
        generation_config: Optional[GenerationConfigType] = None,
        safety_settings: Optional[SafetySettingsType] = None,
    ) -> prediction_service_types.GenerateContentRequest:
        if not contents:
            raise TypeError("contents must not be empty")

        # contents can either be a list of Content objects (most generic case)
        if isinstance(contents, Sequence) and any(isinstance(c, content_types.Content) for c in contents):
            if not all(isinstance(c, content_types.Content) for c in contents):
                raise TypeError(
                    "When passing a list with Content objects, every item in a list must be a Content object."
                )
        # or a value that can be converted to a *single* Content object
        else:
            contents = [_to_content(contents)]

        if generation_config and not isinstance(generation_config, content_types.GenerationConfig):
            generation_config = content_types.GenerationConfig(**generation_config)
        if safety_settings and not isinstance(safety_settings, content_types.SafetySetting):
            safety_settings = content_types.SafetySetting(**safety_settings)
        return prediction_service_types.GenerateContentRequest(
            #model=self._prediction_model_name,
            endpoint=self._prediction_model_name,
            contents=contents,
            generation_config=generation_config,
            safety_settings=safety_settings,
        )

    def _parse_response(
        self,
        response: prediction_service_types.GenerateContentResponse,
    ) -> prediction_service_types.GenerateContentResponse:
        # TODO(avolkov): Convert from GAPIC class to a hand-written class
        # Be careful about chat
        return response

    def generate_content(
        self,
        contents: ContentsType,
        *,
        generation_config: Optional[GenerationConfigType] = None,
        safety_settings: Optional[SafetySettingsType] = None,
    ) -> prediction_service_types.GenerateContentResponse:
        request = self._prepare_request(
            contents=contents,
            generation_config=generation_config,
            safety_settings=safety_settings,
        )
        response = self._prediction_client.generate_content(request=request)
        return self._parse_response(response)

    async def generate_content_async(
        self,
        contents: ContentsType,
        *,
        generation_config: Optional[GenerationConfigType] = None,
        safety_settings: Optional[SafetySettingsType] = None,
    ) -> prediction_service_types.GenerateContentResponse:
        request = self._prepare_request(
            contents=contents,
            generation_config=generation_config,
            safety_settings=safety_settings,
        )
        response = await self._prediction_async_client.generate_content(request=request)
        return self._parse_response(response)

    def generate_content_streaming(
        self,
        contents: ContentsType,
        *,
        generation_config: Optional[GenerationConfigType] = None,
        safety_settings: Optional[SafetySettingsType] = None,
    ) -> Iterable[prediction_service_types.GenerateContentResponse]:
        request = self._prepare_request(
            contents=contents,
            generation_config=generation_config,
            safety_settings=safety_settings,
        )
        response_stream = self._prediction_client.stream_generate_content(request=request)
        for response in response_stream:
            yield self._parse_response(response)

    async def generate_content_streaming_async(
        self,
        contents: ContentsType,
        *,
        generation_config: Optional[GenerationConfigType] = None,
        safety_settings: Optional[SafetySettingsType] = None,
    ) -> AsyncIterable[prediction_service_types.GenerateContentResponse]:
        request = self._prepare_request(
            contents=contents,
            generation_config=generation_config,
            safety_settings=safety_settings,
        )
        response_stream = await self._prediction_async_client.stream_generate_content(request=request)
        async for response in response_stream:
            yield self._parse_response(response)

    def start_chat(
        self,
        *,
        history: Optional[List[content_types.Content]] = None,
    ) -> "ChatSession":
        return ChatSession(
            model=self,
            history=history,
        )


class ChatSession:
    _USER_ROLE = "user"
    _MODEL_ROLE = "assistant"

    def __init__(
        self,
        model: GenerativeModel,
        history: Optional[List[content_types.Content]] = None,
    ):
        self._model = model
        self._history = history or []

    @property
    def history(self) -> List[content_types.Content]:
        return self._history

    def send_message(
        self,
        content: PartsType,
        *,
        generation_config: Optional[GenerationConfigType] = None,
        safety_settings: Optional[SafetySettingsType] = None,

    ) -> prediction_service_types.GenerateContentResponse:
        # Preparing the message history to send
        request_message = _to_content(value=content, role=self._USER_ROLE)
        request_history = list(self._history)
        request_history.append(request_message)

        response = self._model.generate_content(
            contents=request_history,
            generation_config=generation_config,
            safety_settings=safety_settings,
        )
        # Adding the request and the first response candidate to history
        response_message = response.candidates[0].content
        # Response role is NOT set by the model.
        response_message.role = self._MODEL_ROLE
        self._history.append(request_message)
        self._history.append(response_message)
        return response

    async def send_message_async(
        self,
        content: PartsType,
        *,
        generation_config: Optional[GenerationConfigType] = None,
        safety_settings: Optional[SafetySettingsType] = None,

    ) -> prediction_service_types.GenerateContentResponse:
        # Preparing the message history to send
        request_message = _to_content(value=content, role=self._USER_ROLE)
        request_history = list(self._history)
        request_history.append(request_message)

        response = await self._model.generate_content_async(
            contents=request_history,
            generation_config=generation_config,
            safety_settings=safety_settings,
        )
        # Adding the request and the first response candidate to history
        response_message = response.candidates[0].content
        # Response role is NOT set by the model.
        response_message.role = self._MODEL_ROLE
        self._history.append(request_message)
        self._history.append(response_message)
        return response

    def send_message_streaming(
        self,
        content: PartsType,
        *,
        generation_config: Optional[GenerationConfigType] = None,
        safety_settings: Optional[SafetySettingsType] = None,
    ) -> Iterable[prediction_service_types.GenerateContentResponse]:
        # Preparing the message history to send
        request_message = _to_content(value=content, role=self._USER_ROLE)
        request_history = list(self._history)
        request_history.append(request_message)

        full_response = prediction_service_types.GenerateContentResponse()
        for chunk in self._model.generate_content_streaming(
            contents=request_history,
            generation_config=generation_config,
            safety_settings=safety_settings,
        ):
            yield chunk
            _append_response(full_response, chunk)

        # Adding the request and the first response candidate to history
        response_message = full_response.candidates[0].content
        # Response role is NOT set by the model.
        response_message.role = self._MODEL_ROLE
        self._history.append(request_message)
        self._history.append(response_message)

    async def send_message_streaming_async(
        self,
        content: PartsType,
        *,
        generation_config: Optional[GenerationConfigType] = None,
        safety_settings: Optional[SafetySettingsType] = None,
    ) -> AsyncIterable[prediction_service_types.GenerateContentResponse]:
        # Preparing the message history to send
        request_message = _to_content(value=content, role=self._USER_ROLE)
        request_history = list(self._history)
        request_history.append(request_message)

        full_response = prediction_service_types.GenerateContentResponse()
        async for chunk in self._model.generate_content_streaming_async(
            contents=request_history,
            generation_config=generation_config,
            safety_settings=safety_settings,
        ):
            yield chunk
            _append_response(full_response, chunk)

        # Adding the request and the first response candidate to history
        response_message = full_response.candidates[0].content
        # Response role is NOT set by the model.
        response_message.role = self._MODEL_ROLE
        self._history.append(request_message)
        self._history.append(response_message)


class GenerationResponse:

    def __init__(self, _raw_response: prediction_service_types.GenerateContentResponse):
        self._raw_response = _raw_response

    @property
    def candidates(self) -> List["GenerationCandidate"]:
        return [
            GenerationCandidate(_raw_candidate=candidate)
            for candidate in self._raw_response.candidates
        ]

    # GenerationCandidate properties
    @property
    def finish_reason(self) -> content_types.Candidate.FinishReason:
        return self.candidates[0].finish_reason

    # GenerationPart properties
    @property
    def text(self) -> str:
        return self.candidates[0].content.parts[0].text

    def __iadd__(self, other: "GenerationResponse"):
        _append_response(self._raw_response, other._raw_response)
        return self


class GenerationCandidate:

    def __init__(self, _raw_candidate: content_types.Candidate):
        self._raw_candidate = _raw_candidate

    @property
    def content(self) -> "GenerationContent":
        return GenerationContent(
            _raw_content=self._raw_candidate.content,
        )

    @property
    def finish_reason(self) -> content_types.Candidate.FinishReason:
        return self._raw_candidate.finish_reason

    # GenerationPart properties
    @property
    def text(self) -> str:
        return self.content.parts[0].text

    def __iadd__(self, other: "GenerationCandidate"):
        _append_candidate(self._raw_candidate, other._raw_candidate)
        return self


class GenerationContent:

    def __init__(self, _raw_content: content_types.Content):
        self._raw_content = _raw_content

    @property
    def parts(self) -> List["GenerationPart"]:
        return [GenerationPart(_raw_part=part) for part in self._raw_content.parts]

    @property
    def role(self) -> str:
        return self._raw_content.role

    # GenerationPart properties
    @property
    def text(self) -> str:
        return self.parts[0].text


class GenerationPart:

    def __init__(self, _raw_part: content_types.Part):
        self._raw_part = _raw_part

    @staticmethod
    def from_data(data: bytes, mime_type: str) -> "GenerationPart":
        return GenerationPart(
            _raw_part=content_types.Part(inline_data=content_types.Blob(data=data, mime_type=mime_type))
        )

    @staticmethod
    def from_text(text: str) -> "GenerationPart":
        return GenerationPart(_raw_part=content_types.Part(text=text))

    @staticmethod
    def from_image(image: "Image") -> "GenerationPart":
        return GenerationPart.from_data(data=image.data, mime_type=image._mime_type)

    @property
    def text(self) -> str:
        return self._raw_part.text

    @property
    def image(self) -> "Image":
        return Image(image_bytes=self._raw_part.inline_data.data)

    @property
    def _mime_type(self) -> Optional[str]:
        return self._raw_part.mime_type

    def __iadd__(self, other: "GenerationPart"):
        _append_part(self._raw_part, other._raw_part)
        return self


def _to_content(
    value: Union[
        content_types.Content,
        content_types.Part,
        str,
        "Image",
        List[Union[content_types.Part, str, "Image"]],
    ],
    role: str = GenerativeModel._USER_ROLE,
) -> content_types.Content:
    if not value:
        raise TypeError("value must not be empty")
    if isinstance(value, content_types.Content):
        return value
    if isinstance(value, (str, Image, content_types.Part)):
        items = [value]
    elif isinstance(value, list):
        items = value
    else:
        raise TypeError(f"Unexpected value type: {value}")
    parts: List[content_types.Part] = []
    for item in items:
        if isinstance(item, content_types.Part):
            part = item
        elif isinstance(item, str):
            part = content_types.Part(text=item)
        elif isinstance(item, Image):
            part = content_types.Part(inline_data=content_types.Blob(data=item.data, mime_type=item._mime_type))
        elif isinstance(item, content_types.Content):
            raise TypeError(f"_to_content does not support a list of Content objects: {value}")
        else:
            raise TypeError(f"Unexpected item type: {item}")
        parts.append(part)
    return content_types.Content(parts=parts, role=role)


def _append_response(
    base_response: prediction_service_types.GenerateContentResponse,
    new_response: prediction_service_types.GenerateContentResponse,
):
    for idx, candidate in enumerate(new_response.candidates):
        if idx < len(base_response.candidates):
            _append_candidate(base_response.candidates[idx], candidate)
        else:
            assert(idx == len(base_response.candidates))
            base_response.candidates.append(candidate)


def _append_candidate(
    base_candidate: content_types.Candidate,
    new_candidate: content_types.Candidate,
):
    for part_idx, part in enumerate(new_candidate.content.parts):
        if part_idx < len(base_candidate.content.parts):
            _append_part(base_candidate.content.parts[part_idx], part)
        else:
            assert(part_idx == len(new_candidate.content.parts))
            base_candidate.content.parts.append(part)


def _append_part(
    base_part: content_types.Part,
    new_part: content_types.Part,
):
    base_part.text += new_part.text


_FORMAT_TO_MIME_TYPE = {
    "png": "image/png",
    "jpeg": "image/jpeg",
    "gif": "image/gif",
}


class Image:
    """Image."""

    _image_bytes: bytes
    _loaded_image: Optional["PIL_Image.Image"] = None

    def __init__(self, image_bytes: bytes):
        """Creates an `Image` object.

        Args:
            image_bytes: Image file bytes. Image can be in PNG or JPEG format.
        """
        self._image_bytes = image_bytes

    @staticmethod
    def load_from_file(location: str) -> "Image":
        """Loads image from file.

        Args:
            location: Local path from where to load the image.

        Returns:
            Loaded image as an `Image` object.
        """
        image_bytes = pathlib.Path(location).read_bytes()
        image = Image(image_bytes=image_bytes)
        return image

    @property
    def _pil_image(self) -> "PIL_Image.Image":
        if self._loaded_image is None:
            self._loaded_image = PIL_Image.open(io.BytesIO(self._image_bytes))
        return self._loaded_image

    @property
    def _mime_type(self) -> str:
        """Returns the MIME type of the image."""
        return _FORMAT_TO_MIME_TYPE[self._pil_image.format.lower()]

    @property
    def data(self) -> bytes:
        """Returns the image data."""
        return self._image_bytes

    def _repr_png_(self):
        return self._pil_image._repr_png_()

    # For some reason PIL.JpegImagePlugin.JpegImageFile._repr_jpeg_ does not exist
    # def _repr_jpeg_(self):
    #     return self._pil_image._repr_jpeg_()

    # Does not help with images
    # def _repr_pretty_(self, *args, **kwargs):
    #     self._pil_image._repr_pretty_(*args, **kwargs)
